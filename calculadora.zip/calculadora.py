from tkinter import *
from sp import suma, resta, multi, div, distanciam, distanciae

# Función para mostrar resultados
def mostrar_resultado(valor):
    resultado_label.config(text=f"Resultado: {valor}")


def realizar_suma():
    x = float(entrada1.get())
    y = float(entrada2.get())
    mostrar_resultado(suma(x, y))

def realizar_resta():
    x = float(entrada1.get())
    y = float(entrada2.get())
    mostrar_resultado(resta(x, y))

def realizar_multiplicacion():
    x = float(entrada1.get())
    y = float(entrada2.get())
    mostrar_resultado(multi(x, y))

def realizar_division():
    x = float(entrada1.get())
    y = float(entrada2.get())
    if y == 0:
        mostrar_resultado("Error: División por cero")
    else:
        mostrar_resultado(div(x, y))

def realizar_dist_manhattan():
    x1 = float(entrada1.get())
    y1 = float(entrada2.get())
    x2 = float(entrada3.get())
    y2 = float(entrada4.get())
    mostrar_resultado(distanciam(x1, y1, x2, y2))

def realizar_dist_euclidiana():
    x1 = float(entrada1.get())
    y1 = float(entrada2.get())
    x2 = float(entrada3.get())
    y2 = float(entrada4.get())
    mostrar_resultado(distanciae(x1, y1, x2, y2))


ventana = Tk()
ventana.title("Calculadora Simple")


Label(ventana, text="X o X1:").grid(row=0, column=0)
entrada1 = Entry(ventana)
entrada1.grid(row=0, column=1)

Label(ventana, text="Y o Y1:").grid(row=1, column=0)
entrada2 = Entry(ventana)
entrada2.grid(row=1, column=1)

Label(ventana, text="X2 (solo para distancia):").grid(row=2, column=0)
entrada3 = Entry(ventana)
entrada3.grid(row=2, column=1)

Label(ventana, text="Y2 (solo para distancia):").grid(row=3, column=0)
entrada4 = Entry(ventana)
entrada4.grid(row=3, column=1)


Button(ventana, text="Sumar", command=realizar_suma).grid(row=4, column=0)
Button(ventana, text="Restar", command=realizar_resta).grid(row=4, column=1)
Button(ventana, text="Multiplicar", command=realizar_multiplicacion).grid(row=5, column=0)
Button(ventana, text="Dividir", command=realizar_division).grid(row=5, column=1)


Button(ventana, text="Distancia Manhattan", command=realizar_dist_manhattan).grid(row=6, column=0)
Button(ventana, text="Distancia Euclidiana", command=realizar_dist_euclidiana).grid(row=6, column=1)


resultado_label = Label(ventana, text="Resultado: ")
resultado_label.grid(row=7, column=0, columnspan=2)


ventana.mainloop()
