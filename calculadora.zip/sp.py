##########codigo paralelo
def suma(x,y):
    res=(x+y)
    return(res)

def resta(x,y):
    res=(x-y)
    return(res)

def multi(x,y):
    res=(x*y)
    return(res)

def div(x,y):
    res=(x/y)
    return(res)

def distanciam(x1, y1, x2, y2):
    return abs(x1 - x2) + abs(y1 - y2)
def distanciae(x1, y1, x2, y2):
    return sqrt((x1 - x2)**2 + (y1 - y2)**2)